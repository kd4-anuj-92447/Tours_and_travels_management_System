const NotFound = () => (
  <div className="container mt-4">
    <h2>404 - Page Not Found</h2>
  </div>
);

export default NotFound;
