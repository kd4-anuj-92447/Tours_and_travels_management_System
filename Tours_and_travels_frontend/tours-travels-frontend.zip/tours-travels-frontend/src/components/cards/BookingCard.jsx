const BookingCard = () => (
  <div className="card shadow p-3">
    <h5>Booking #123</h5>
    <p>Status: Confirmed</p>
  </div>
);

export default BookingCard;

