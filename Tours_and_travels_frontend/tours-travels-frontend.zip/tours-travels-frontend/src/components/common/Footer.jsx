const Footer = () => (
  <footer className="bg-dark text-white text-center p-3 mt-4">
    © 2026 Tours & Travels Management System
  </footer>
);

export default Footer;
