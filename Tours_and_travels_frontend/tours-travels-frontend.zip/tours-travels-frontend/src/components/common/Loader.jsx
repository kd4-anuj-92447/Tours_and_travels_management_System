const Loader = () => (
  <div className="text-center mt-5">
    <div className="spinner-border"></div>
  </div>
);

export default Loader;
