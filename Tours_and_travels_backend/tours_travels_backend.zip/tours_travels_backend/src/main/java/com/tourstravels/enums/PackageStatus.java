package com.tourstravels.enums;

public enum PackageStatus {
	 PENDING,
	    APPROVED,
	    REJECTED, 
	    PENDING_DELETE
}
