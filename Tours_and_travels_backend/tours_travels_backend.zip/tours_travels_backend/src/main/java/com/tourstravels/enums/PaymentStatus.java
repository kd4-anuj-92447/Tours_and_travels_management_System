package com.tourstravels.enums;

public enum PaymentStatus {
	 INITIATED,
	    SUCCESS,
	    FAILED,
	    REFUNDED, 
	    PENDING
}
